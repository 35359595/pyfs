#!/bin/bash/env python3
import tvcheck
