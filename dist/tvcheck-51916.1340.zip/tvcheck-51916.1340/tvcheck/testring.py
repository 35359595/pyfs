def helpstring():
    print('Welcome to fs.to tv series checker by Ivan Temchenko (c) 2016

            USAGE:

                tvcheck <?> 
            
            PARAMETERS<?>:
            
            h   -   calls this help;
            l   -   lists series added to the local list;
            n   -   adds new series to list from URL provided (follow the instructions);
                    
            Multiple parameters are not supported!
            Have a nice day!
    
        ')
